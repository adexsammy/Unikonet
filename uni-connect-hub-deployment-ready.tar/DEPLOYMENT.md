# UniConnect Hub — Deployment Guide

## Project Overview

**UniConnect Hub** is a React + TypeScript mobile-first web app built with Vite, Tailwind CSS, and shadcn/ui. It serves as a comprehensive university social platform with the following feature modules:

| Module | Routes | Description |
|--------|--------|-------------|
| Auth | `/`, `/login`, `/select-university`, `/setup` | Splash, login, university selection, profile setup |
| Social Feed | `/feed`, `/post/:postId` | Social timeline and post detail |
| Discover | `/discover`, `/search` | Explore and search content |
| UniStore | `/store`, `/product/:productId`, `/cart`, `/checkout`, `/payment-processing`, `/orders`, `/wishlist`, `/seller/:sellerName` | Full e-commerce flow |
| Ride | `/ride`, `/ride/:rideId` | Campus ride-sharing |
| Chat | `/chat`, `/chat/:chatId` | Messaging |
| Profile | `/profile`, `/user/:userId` | User profiles |
| Notifications | `/notifications` | Activity alerts |
| Media | `/media/:mediaId` | Media viewer |

**Tech Stack:** React 18, TypeScript, Vite, Tailwind CSS, shadcn/ui, Zustand, React Router v6, TanStack Query, Capacitor (mobile)

---

## Vercel Deployment (Recommended)

### Option A: Via Vercel CLI

```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. From project root, install dependencies
npm install

# 3. Deploy
vercel

# Follow the prompts:
#   - Set up and deploy: Y
#   - Which scope: your account
#   - Link to existing project: N (first time)
#   - Project name: uni-connect-hub
#   - In which directory is your code: ./
#   - Override settings: N (vercel.json handles it)
```

### Option B: Via Vercel Dashboard (GitHub)

1. Push this project to a GitHub repository
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import the repository
4. Vercel auto-detects Vite — confirm these settings:
   - **Framework Preset:** Vite
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
   - **Install Command:** `npm install`
5. Click **Deploy**

### Option C: Deploy Prebuilt `dist/`

The `dist/` folder is already built and included. You can deploy it directly:

```bash
vercel --prebuilt
# Point output directory to: dist
```

---

## Local Development

```bash
npm install
npm run dev
# Opens at http://localhost:8080
```

---

## Build for Production

```bash
npm run build
# Output in: dist/
```

---

## Environment Variables

Copy `.env.example` to `.env.local` and fill in values as needed.

No environment variables are required for the current mock-data version. Add them when connecting a real backend (Supabase, etc.).

---

## Architecture Notes

### State Management
- **Zustand** (`src/store/useAppStore.ts`) — single global store managing user, cart, wishlist, notifications, feed, and ride state
- **TanStack Query** — for server state (ready for API integration)

### Routing
- React Router v6 with two layout tiers:
  - **Full-screen** routes (no tab bar): auth flow, product detail, checkout, etc.
  - **MainLayout** routes (with persistent bottom tab nav): feed, store, ride, chat, profile, discover

### Data
- All data is currently mock (`src/data/mockData.ts`, `src/data/universities.ts`)
- Ready for Supabase or REST API integration by replacing mock calls in `useAppStore.ts`

### Mobile (Capacitor)
- Configured for iOS/Android via Capacitor
- Run `npx cap add ios` or `npx cap add android` after `npm run build` to scaffold native projects

---

## Known Issues / Deployment Checklist

- [x] `vercel.json` SPA rewrite rule added (all routes → `index.html`)
- [x] Capacitor config cleaned (removed Lovable dev server reference)
- [x] `.gitignore` updated (excludes `.env`, `node_modules`, `dist`, `android/`, `ios/`)
- [ ] Replace mock data with real API/Supabase calls when backend is ready
- [ ] Add real OG image to `public/` and update `index.html` meta tags
- [ ] Configure custom domain in Vercel dashboard post-deployment
