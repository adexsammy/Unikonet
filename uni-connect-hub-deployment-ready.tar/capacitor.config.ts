import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.uniconnect.hub',
  appName: 'UniConnect Hub',
  webDir: 'dist',
  bundledWebRuntime: false,
};

export default config;
